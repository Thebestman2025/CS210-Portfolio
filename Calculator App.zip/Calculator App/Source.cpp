/*
 * Calculator.cpp
 *
 *  Date: 11/09/2024
 *  Author: Ibrahim Abdul
 */

#include <iostream> // Include necessary library for input/output
using namespace std;

int main() // Corrected return type from void to int
{
    char statement[100]; // Variable for storing user statement (unused but kept for reference)
    int op1, op2;        // Variables for operands
    char operation;      // Variable for operator
    char answer = 'Y';   // Correctly initialized answer with single quotes (for a character)

    while (answer == 'Y' || answer == 'y') { // Allow both uppercase and lowercase 'Y' for continuation
        cout << "Enter an expression (e.g., 2 + 3): " << endl;
        cin >> op1 >> operation >> op2; // Read operands and operator from user

        // Perform operations based on the operator
        if (operation == '+') {
            cout << op1 << " + " << op2 << " = " << op1 + op2 << endl;
        }
        else if (operation == '-') {
            cout << op1 << " - " << op2 << " = " << op1 - op2 << endl;
        }
        else if (operation == '*') {
            cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;
        }
        else if (operation == '/') {
            if (op2 == 0) { // Handle division by zero
                cout << "Erro
