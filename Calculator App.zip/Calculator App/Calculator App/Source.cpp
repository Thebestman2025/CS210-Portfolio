/*
 * Calculator.cpp
 *
 *  Date: [11/15/2025]
 *  Author: [Ibrahim Abdul]
 */

#include <iostream> 
using namespace std;

int main() 
{
    char statement[100];
    int op1, op2;       
    char operation;     
    char answer = 'Y';   

    while (answer == 'Y' || answer == 'y') { 
        cout << "Enter an expression (e.g., 2 + 3): " << endl;
        cin >> op1 >> operation >> op2; 

        
        if (operation == '+') {
            cout << op1 << " + " << op2 << " = " << op1 + op2 << endl;
        }
        else if (operation == '-') {
            cout << op1 << " - " << op2 << " = " << op1 - op2 << endl;
        }
        else if (operation == '*') {
            cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;
        }
        else if (operation == '/') {
            if (op2 == 0) {
                cout << "Error: Division by zero is not allowed." << endl;
            }
            else {
                cout << op1 << " / " << op2 << " = " << op1 / op2 << endl;
            }
        }
        else {
            cout << "Error: Unsupported operator. Please use +, -, *, or /." << endl;
        }

        
        cout << "Do you wish to evaluate another expression? (Y/N): " << endl;
        cin >> answer;
    }

    cout << "Program Finished." << endl; 
    return 0; 
}