// Developer: Ibrahim Abdul
// Date  : 11/02/2024
// Purpose: This Program Prints "Hello World!" to console.

// include the iostream library for input and output operations
#Include <iostream>

// Use the standard namespace to avoid prefixing with 'std::'
using namespace std;

int main() {
	// print "Hello, World!" to the console
	cout << "Hello World" << end1;

	// Pause the console to view the output before the program exits
	// (This may not be needed depending on your visual studio settings)

	// Return 0 to indicate the program has run successfully
	return 0;
}
		